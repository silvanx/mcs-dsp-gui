using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using UsbNetDll;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        CMcsUsbListNet UsbDeviceList = new CMcsUsbListNet();

        public Form1()
        {
            InitializeComponent();
            RefreshDeviceList();
        }

        private void RefreshDeviceList()
        {
            UsbDeviceList.Initialize(DeviceEnumNet.MCS_DEVICE_USB);
            cbDeviceList.Items.Clear();
            for (uint i = 0; i < UsbDeviceList.Count; i++)
            {
                cbDeviceList.Items.Add(UsbDeviceList.GetUsbListEntry(i));
            }
            if (cbDeviceList.Items.Count > 0)
            {
                cbDeviceList.SelectedIndex = 0;
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshDeviceList();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            CMcsUsbNet device = new CMcsUsbNet();
            if (device.Connect((CMcsUsbListEntryNet)cbDeviceList.SelectedItem) == 0)
            {
                device.Disconnect();
            }
        }
    }
}
